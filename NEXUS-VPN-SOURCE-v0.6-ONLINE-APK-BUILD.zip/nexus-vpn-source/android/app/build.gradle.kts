plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.nexusvpn.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.nexusvpn.app"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "0.2.0" }
}

dependencies {
    implementation("com.google.zxing:core:3.5.3")
}
