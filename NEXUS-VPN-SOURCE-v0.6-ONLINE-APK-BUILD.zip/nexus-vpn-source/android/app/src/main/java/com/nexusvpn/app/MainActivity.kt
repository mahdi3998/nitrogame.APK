package com.nexusvpn.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.os.StrictMode
import android.graphics.BitmapFactory
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64

/** NEXUS VPN client scaffold: imports and local profile management. VPN engines are not yet integrated. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var configBox: EditText
    private lateinit var protocol: Spinner
    private lateinit var profileList: Spinner
    private val blue = Color.rgb(0, 150, 255)
    private val bg = Color.rgb(7, 16, 31)
    private val card = Color.rgb(17, 32, 54)
    private val cyan = Color.rgb(78, 219, 255)
    private val prefs by lazy { getSharedPreferences("nexus", MODE_PRIVATE) }
    private fun profiles(): MutableList<String> = prefs.getStringSet("profiles", emptySet())!!.toMutableList().sorted().toMutableList()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }

    private fun render() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,24,22,20); setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,0,0,12) }
        fun label(s:String,size:Float,color:Int=Color.WHITE)=TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,8,0,8) }
        content.addView(label("NEXUS VPN",29f,cyan))
        content.addView(label("اتصال امن · WireGuard و V2Ray",15f,Color.LTGRAY))
        status=label("وضعیت: آماده واردکردن کانفیگ",15f,Color.LTGRAY); content.addView(status)
        val connect=Button(this).apply { text="اتصال"; setBackgroundColor(blue); setTextColor(Color.WHITE); setOnClickListener { status.text="موتور اتصال هنوز نصب نشده است؛ این نسخه تونل VPN ایجاد نمی‌کند."; Toast.makeText(this@MainActivity,"برای اتصال واقعی باید موتور WireGuard و V2Ray ادغام شود.",Toast.LENGTH_LONG).show() } }
        content.addView(connect, LinearLayout.LayoutParams(-1,-2))
        content.addView(label("پروتکل کانفیگ",16f,cyan))
        protocol=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("WireGuard", "V2Ray / VLESS / VMess / Trojan")) }
        content.addView(protocol)
        content.addView(label("افزودن کانفیگ",16f,cyan))
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        fun actionButton(caption:String, action:()->Unit)=Button(this).apply { text=caption; setOnClickListener { action() } }
        row.addView(actionButton("فایل کانفیگ") { pickFile(false) }, LinearLayout.LayoutParams(0,-2,1f))
        row.addView(actionButton("QR از تصویر") { pickFile(true) }, LinearLayout.LayoutParams(0,-2,1f))
        content.addView(row)
        configBox=EditText(this).apply { hint="لینک VLESS/VMess یا Subscription یا متن کانفیگ WireGuard"; setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setBackgroundColor(card); minLines=4; gravity=Gravity.TOP; setPadding(12,12,12,12) }
        content.addView(configBox, LinearLayout.LayoutParams(-1,-2))
        content.addView(actionButton("دریافت لینک Subscription") { fetchSubscription() }, LinearLayout.LayoutParams(-1,-2))
        content.addView(actionButton("ذخیره کانفیگ روی گوشی") { saveProfile() }, LinearLayout.LayoutParams(-1,-2))
        content.addView(label("کانفیگ‌های ذخیره‌شده",16f,cyan))
        profileList=Spinner(this); refreshProfiles(); content.addView(profileList)
        content.addView(actionButton("بارگذاری کانفیگ انتخاب‌شده") { loadSelected() }, LinearLayout.LayoutParams(-1,-2))
        content.addView(actionButton("حذف کانفیگ انتخاب‌شده") { deleteSelected() }, LinearLayout.LayoutParams(-1,-2))
        content.addView(label("نکته: این نسخه واردکردن و ذخیره‌سازی را فراهم می‌کند؛ اتصال واقعی VPN هنوز ادغام نشده است.",12f,Color.LTGRAY))
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
        configBox.setText(prefs.getString("draft", ""))
    }

    private fun pickFile(image:Boolean) {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type=if(image) "image/*" else "*/*" }
        startActivityForResult(i, if(image) 102 else 100)
    }

    private fun saveProfile() {
        val value=configBox.text.toString().trim()
        if(value.isBlank()) { toast("ابتدا لینک یا متن کانفیگ را وارد کن."); return }
        val type=if(protocol.selectedItemPosition==0) "WireGuard" else "V2Ray"
        val name=type+" · "+(value.lineSequence().firstOrNull()?.take(42) ?: "کانفیگ")
        val all=prefs.getStringSet("profiles", emptySet())!!.toMutableSet(); all.add(name); prefs.edit().putStringSet("profiles",all).putString("profile:"+name,value).putString("type:"+name,type).putString("draft",value).apply()
        refreshProfiles(); toast("کانفیگ روی همین گوشی ذخیره شد.")
    }
    private fun refreshProfiles() { if(!::profileList.isInitialized) return; val names=profiles(); profileList.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,if(names.isEmpty()) listOf("هنوز کانفیگی ذخیره نشده") else names) }
    private fun loadSelected() { val n=profileList.selectedItem?.toString() ?: return; val value=prefs.getString("profile:"+n,null); if(value==null) toast("اول یک کانفیگ ذخیره کن.") else { configBox.setText(value); protocol.setSelection(if(prefs.getString("type:"+n,"WireGuard")=="WireGuard") 0 else 1); toast("کانفیگ بارگذاری شد.") } }
    private fun deleteSelected() { val n=profileList.selectedItem?.toString() ?: return; val all=prefs.getStringSet("profiles",emptySet())!!.toMutableSet(); if(!all.remove(n)) { toast("کانفیگی برای حذف وجود ندارد."); return }; prefs.edit().putStringSet("profiles",all).remove("profile:"+n).remove("type:"+n).apply(); refreshProfiles(); toast("کانفیگ حذف شد.") }

    private fun fetchSubscription() {
        val link=configBox.text.toString().trim()
        if(!link.startsWith("https://") && !link.startsWith("http://")) { toast("لینک Subscription را ابتدا داخل کادر وارد کن."); return }
        status.text="در حال دریافت Subscription…"
        Thread {
            var result:String?=null
            try {
                val c=URL(link).openConnection() as HttpURLConnection; c.connectTimeout=10000; c.readTimeout=15000; c.instanceFollowRedirects=true
                c.setRequestProperty("User-Agent","NEXUS-VPN/0.2")
                c.inputStream.use { result=it.bufferedReader().readText().take(500000) }; c.disconnect()
                if(result!!.trim().matches(Regex("^[A-Za-z0-9+/=\\r\\n]+$")) && !result!!.contains("://")) try { result=String(Base64.decode(result,Base64.DEFAULT)) } catch (_:Exception) {}
            } catch (_:Exception) {}
            runOnUiThread { if(result.isNullOrBlank()) { status.text="دریافت Subscription ناموفق بود"; toast("لینک قابل دریافت نیست یا پاسخ خالی است.") } else { configBox.setText(result); status.text="Subscription دریافت شد؛ برای نگه‌داشتن ذخیره کن." } }
        }.start()
    }

    @Deprecated("Kept for broad Android compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data); if(resultCode!=Activity.RESULT_OK) return
        val uri=data?.data ?: return
        try {
            if(requestCode==102) {
                val bitmap=contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: throw Exception("image")
                val pixels=IntArray(bitmap.width*bitmap.height); bitmap.getPixels(pixels,0,bitmap.width,0,0,bitmap.width,bitmap.height)
                val source=RGBLuminanceSource(bitmap.width,bitmap.height,pixels); val result=MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(source)))
                configBox.setText(result.text); status.text="QR خوانده شد؛ پروتکل را انتخاب و ذخیره کن."
            } else {
                val value=contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(500000) } ?: ""
                configBox.setText(value); status.text="فایل بارگذاری شد؛ پروتکل را بررسی کن."
            }
        } catch (_:Exception) { toast("خواندن فایل یا QR ناموفق بود.") }
    }
    private fun toast(s:String) = Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
