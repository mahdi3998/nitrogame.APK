<?php
declare(strict_types=1);
$root=__DIR__; $lock=$root.'/storage/install.lock'; $configFile=$root.'/config.php';
if (is_file($lock) || is_file($configFile)) { http_response_code(403); exit('نصب قبلاً انجام شده است. برای امنیت، نصب‌کننده قفل شده است.'); }
$error=''; $done=false;
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $host=trim($_POST['db_host']??'localhost'); $db=trim($_POST['db_name']??''); $user=trim($_POST['db_user']??''); $pass=(string)($_POST['db_pass']??''); $admin=trim($_POST['admin_user']??'admin'); $pw=(string)($_POST['admin_pass']??'');
  if ($db==='' || $user==='' || strlen($admin)<3 || strlen($pw)<12) $error='نام دیتابیس، کاربر و مدیر الزامی است؛ رمز مدیر حداقل ۱۲ کاراکتر باشد.';
  else {
    try {
      $dsn="mysql:host={$host};dbname={$db};charset=utf8mb4";
      $pdo=new PDO($dsn,$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
      $pdo->exec("CREATE TABLE IF NOT EXISTS admins (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, username VARCHAR(80) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $pdo->exec("CREATE TABLE IF NOT EXISTS servers (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, protocol ENUM('WireGuard','V2Ray') NOT NULL, region VARCHAR(100) DEFAULT '', config_uri TEXT NULL, enabled TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $st=$pdo->prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)'); $st->execute([$admin,password_hash($pw,PASSWORD_DEFAULT)]);
      if (!is_dir($root.'/storage')) mkdir($root.'/storage',0750,true);
      $cfg="<?php\nreturn ".var_export(['dsn'=>$dsn,'db_user'=>$user,'db_pass'=>$pass],true).";\n";
      if (file_put_contents($configFile,$cfg,LOCK_EX)===false) throw new RuntimeException('نمی‌توان config.php را ساخت. مجوز نوشتن پوشه را بررسی کنید.');
      file_put_contents($lock,'installed '.date(DATE_ATOM),LOCK_EX); $done=true;
    } catch(Throwable $e) { $error='نصب ناموفق بود. اطلاعات دیتابیس و مجوز نوشتن پوشه را بررسی کنید.'; }
  }
}
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>نصب آنلاین NEXUS VPN</title><style>body{margin:0;background:#07101f;color:#e8f4ff;font:16px Tahoma,Arial;display:grid;min-height:100vh;place-items:center}.card{width:min(540px,92vw);box-sizing:border-box;background:#0d1a2e;border:1px solid #14517b;border-radius:22px;padding:26px;box-shadow:0 20px 80px #0008}h1{color:#4edbff}label{display:block;margin:12px 0 5px}input{width:100%;box-sizing:border-box;padding:12px;border-radius:10px;border:1px solid #234567;background:#071326;color:white}button,a.btn{display:block;width:100%;box-sizing:border-box;margin-top:18px;padding:13px;text-align:center;border:0;border-radius:10px;background:#087ff5;color:white;font-weight:bold;text-decoration:none}.err{color:#ff8f9c}.ok{color:#5af0b0}.hint{color:#a8bfd8;font-size:13px;line-height:1.8}</style><div class="card"><h1>NEXUS VPN</h1><h2>نصب آنلاین پنل</h2><?php if($done): ?><p class="ok">پنل با موفقیت نصب شد.</p><p class="hint">برای امنیت، نصب‌کننده قفل شده است. وارد پنل شوید و در صورت امکان دسترسی به install.php را نیز در هاست ببندید.</p><a class="btn" href="public/login.php">ورود به پنل</a><?php else: ?><?php if($error): ?><p class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></p><?php endif; ?><form method="post"><label>هاست دیتابیس</label><input name="db_host" value="localhost" required><label>نام دیتابیس</label><input name="db_name" required><label>کاربر دیتابیس</label><input name="db_user" required><label>رمز دیتابیس</label><input name="db_pass" type="password"><hr><label>نام کاربری مدیر</label><input name="admin_user" value="admin" required><label>رمز مدیر (حداقل ۱۲ کاراکتر)</label><input name="admin_pass" type="password" minlength="12" required><button>نصب پنل</button></form><p class="hint">قبل از نصب، دیتابیس و کاربر آن را از cPanel بسازید. HTTPS را فعال کنید.</p><?php endif; ?></div></html>
