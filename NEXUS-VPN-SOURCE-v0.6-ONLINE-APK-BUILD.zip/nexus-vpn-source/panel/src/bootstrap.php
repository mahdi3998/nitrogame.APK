<?php
declare(strict_types=1);
$root = dirname(__DIR__);
$configFile = $root . '/config.php';
if (!is_file($configFile)) { http_response_code(503); exit('پنل هنوز نصب نشده است. ابتدا install.php را اجرا کنید.'); }
$config = require $configFile;
try {
  $pdo = new PDO($config['dsn'], $config['db_user'], $config['db_pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch (Throwable $e) { http_response_code(500); exit('اتصال دیتابیس ناموفق بود. تنظیمات هاست را بررسی کنید.'); }
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function require_admin(): void { if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; } }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(403); exit('درخواست نامعتبر است. صفحه را تازه‌سازی کنید.'); } }
